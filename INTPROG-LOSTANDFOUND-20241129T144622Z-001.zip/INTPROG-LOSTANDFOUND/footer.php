<style>
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}   
footer{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}
footer .col{
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    margin-bottom: 20px;
}
footer .logo{
    margin-bottom: 30px;
}
footer h4{
    font-size: 14px;
    padding: 20px;
}
footer p{
    font-size: 13px;
    margin: 0 0 8px 0;
}
footer a{
    font-size: 13px;
    text-decoration: none;
    color: #222;
    margin-bottom: 10px;
}

footer .follow{
    margin-top: 20px;
}
footer .follow{
    color: #465b52;
    padding-right: 4px;
    cursor: pointer;
}
footer .install .row img{
    border: 1px solid #088178;
    border-radius: 6px;
}
footer .install img{
    margin: 10px 0 15px 0;
}
footer .follow i:hover,
footer a:hover{
    color: #088178;
}
footer .copyright{
    width: 100%;
    text-align: center;
}
</style>
<footer class="section-p1">

    <div class="copyright">
        <p>2023, TechTopia Website</p>
    </div>
</footer>

<script src="script.js"></script>
</body>
</html>
